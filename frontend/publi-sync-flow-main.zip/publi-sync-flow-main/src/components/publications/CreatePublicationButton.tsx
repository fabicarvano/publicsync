
import React from 'react';
import PlusIcon from '@/components/icons/PlusIcon';

const CreatePublicationButton: React.FC = () => {
  return (
    <div className="mb-6">
      <button className="w-full py-3 bg-blue-50 text-blue-600 rounded-lg font-medium hover:bg-blue-100 transition-colors duration-200 flex items-center justify-center shadow-sm hover:shadow-md transform hover:-translate-y-1 transition-all">
        <PlusIcon />
        Criar nova publicação
      </button>
    </div>
  );
};

export default CreatePublicationButton;
