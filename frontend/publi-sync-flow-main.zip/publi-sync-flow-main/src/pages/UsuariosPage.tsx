
import React from 'react';

const UsuariosPage: React.FC = () => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Usuários</h2>
      <p className="text-gray-600">Esta página está em construção. Volte em breve para gerenciar os usuários!</p>
    </div>
  );
};

export default UsuariosPage;
