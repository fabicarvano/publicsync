
import React from 'react';
import { useNavigate } from 'react-router-dom';

const LogoutPage: React.FC = () => {
  const navigate = useNavigate();

  React.useEffect(() => {
    // Add actual logout logic here (e.g., clear token, call API)
    console.log("Usuário deslogado (simulação)");
    // Redirect to login or home page after a delay
    const timer = setTimeout(() => {
      navigate('/dashboard'); // Or your login page
    }, 2000);
    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="bg-white p-6 rounded-xl shadow-md border border-gray-100 text-center">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Saindo...</h2>
      <p className="text-gray-600">Você foi desconectado com sucesso. Redirecionando...</p>
    </div>
  );
};

export default LogoutPage;
